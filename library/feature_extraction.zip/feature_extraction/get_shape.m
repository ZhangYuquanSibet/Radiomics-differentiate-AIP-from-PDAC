%% shape_feature  14-d
function shape_feature = get_shape(image)
% image = imread('111.png');
label = get_label(image);
P = regionprops(label,'Area','Perimeter','Centroid','Eccentricity', 'MajorAxisLength','BoundingBox','Solidity');
E = P.Eccentricity; %������
S = P.Solidity;
% ab_rate = P.Area/P.Perimeter;
% center = P.Centroid; %���ģ����ģ�
% [height,width] = size(label);
% �߽�׷��
% rowBegin = floor(height/2);
% for colBegin = 1:width
%     if (label(rowBegin,colBegin)>0)
%         break;
%     end
% end
% label = logical(label);
% pggEdge = bwtraceboundary(label,[rowBegin,colBegin],...
%     'W',8,2*(height+width));
% 
% pggEdgeX = pggEdge(1:end-1,2); %col
% pggEdgeY = pggEdge(1:end-1,1);  %row
% �������
% dist = abs(pggEdgeX-center(1))+abs(pggEdgeY-center(2));
% mu_R = sum(dist)/length(pggEdgeX);
% seit = sum(sqrt((dist - mu_R).^2))/length(pggEdgeX); 
% C = mu_R / sqrt(seit);
% H = 2 * (P.BoundingBox(3)+ P.BoundingBox(4));
% temp = log2((2*P.Perimeter)/(P.Perimeter - H));
%% �������ʵ���״����
% k=LineCurvature2D([pggEdgeX,pggEdgeY]);
% k_mean = mean(k);
% k_std = std(k);
% ��
% k_entropy=0;
% for i=1:length(k)
%       k_entropy=k_entropy-k(i)*log2(k(i));
% end
%������
% BE = sum(k.^2)/length(k);
% rec = P.Area / (P.BoundingBox(3)*P.BoundingBox(4));
% aspect = P.BoundingBox(3)/P.BoundingBox(4);
% compactness = (P.Perimeter)^2/(4*pi*P.Area);
% thinness = 1 / compactness;
% shape_feature = [compactness,thinness,P.Area,P.Perimeter,E,C,ab_rate,mu_R,temp,k_mean,k_std,rec,BE,aspect];
shape_feature = [S,P.Area,P.MajorAxisLength,E];
