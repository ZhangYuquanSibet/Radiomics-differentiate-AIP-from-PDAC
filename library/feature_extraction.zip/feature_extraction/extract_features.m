% feature-extraction

function feature = extract_features (img1) 
   mask = get_label(img1);
   img1 =(1/(max(img1(:))-min(img1(:))))*(img1-min(img1(:)));
   img1 = round(img1*255);
   gray_feature1=feature_ex(img1); %4-d
   
   
%    gd=gray_diff(img1,mask);   % 4������  4
%    gd = [gd1,gd2,gd3,gd4];
   
%    ga1=gaborfeature(img1,mask); 
%    gf1 = GLCM_44(img1,mask,1); 
   ho_feature1 = get_ho_feature(double(img1),64);
   feature = [gray_feature1,ho_feature1];
   
   
   

%    Hu_feature1=Hu(img1);
%    bin =9;%ֱ��ͼ�ķ��������
%    angle =360;%����Ƕȣ�
%    L=1;%ͼ������㣻
%    
%    hog1 = anna_phog(img1,bin,angle,L,[1;size(img1,1);1;size(img1,2)]);
   
   %texture
   %lbp1 = extractLBPFeatures(img1,'CellSize',floor((size(img1)/2)),'Upright',true);  
%    gf1 = GLCM_44(img1,mask); 